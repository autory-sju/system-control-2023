#ifndef __BLC_200_H__
#define __BLC_200_H__

#include "mas001.h"

#define BUFF_LEN 16

class BLC200 {
public:
	BLC200(uint16_t baudrate, long timeout = 1000);

	uint8_t blcData[BUFF_LEN];

	// Protocol MC-RS485_V1.0.1
	void set_PositionWithSpeed(uint8_t ID, uint8_t CW, uint16_t POS, uint16_t SPD);
	void set_PositionWithTime(uint8_t ID, uint8_t CW, uint16_t POS, uint8_t TIME);
	void set_SpeedWithTime(uint8_t ID, uint8_t CW, uint16_t SPD, uint8_t TIME);
	void set_ID(uint8_t ID, uint8_t target_ID);
	void set_RatedSpeed(uint8_t ID, uint16_t RPM);
	void set_Resolution(uint8_t ID, uint16_t resolution);
	void set_ReductionRatio(uint8_t ID, uint16_t reductionRatio);
	void set_PositionMode(uint8_t ID, uint8_t MODE);
	void set_PositionDirection(uint8_t ID, uint8_t DIR);
	void set_PositionInit(uint8_t ID);
	void set_FactorySetting(uint8_t ID);
	bool get_Feedback(uint8_t ID, uint8_t Mode);

	// 추가: 엔코더 값을 읽어오는 함수
	long get_EncoderPosition(uint8_t ID, uint8_t channel);

private:
	uint8_t sendframe[BUFF_LEN];
	uint8_t readframe[BUFF_LEN];
	uint8_t tx_len, rx_len;
	bool transmitReceive(bool recv);
	void getChecksum();
};

#endif
